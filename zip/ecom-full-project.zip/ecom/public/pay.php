<?php
/**
 * Created by PhpStorm.
 * User: edwin
 * Date: 8/22/17
 * Time: 2:29 PM
 */


?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

<h1>It works</h1>

</body>
</html>
