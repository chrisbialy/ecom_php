
<div class="col-md-3">
    <p class="lead">Shop Name</p>
    <div class="list-group">

    	<?php 

    		get_categories();

    	 ?>

    </div>
</div>
